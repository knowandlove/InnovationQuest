import express from 'express';
import { createServer } from 'http';
import { WebSocketServer, WebSocket } from 'ws';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const httpServer = createServer(app);

// Serve static files
app.use(express.static(path.join(__dirname, '../dist/public')));
app.use(express.json());

// Simple in-memory storage
const rooms = new Map();
const connections = new Map();

// WebSocket server
const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

function generateRoomCode() {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let result = '';
  for (let i = 0; i < 6; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}

function broadcastToRoom(roomCode, message, excludeWs) {
  const roomConnections = connections.get(roomCode) || [];
  roomConnections.forEach(ws => {
    if (ws !== excludeWs && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify(message));
    }
  });
}

wss.on('connection', (ws) => {
  console.log('New WebSocket connection');

  ws.on('message', (data) => {
    try {
      const message = JSON.parse(data.toString());
      console.log('Received:', message.type);

      switch (message.type) {
        case 'create_room':
          const roomCode = generateRoomCode();
          rooms.set(roomCode, {
            code: roomCode,
            phase: 'setup',
            problem: null,
            students: [],
            inventions: [],
            votes: []
          });
          
          if (!connections.has(roomCode)) {
            connections.set(roomCode, []);
          }
          connections.get(roomCode).push(ws);
          
          ws.roomCode = roomCode;
          ws.isTeacher = true;
          
          ws.send(JSON.stringify({
            type: 'room_created',
            data: { roomCode }
          }));
          break;

        case 'join_room':
          const { roomCode: joinCode, nickname } = message.data;
          const room = rooms.get(joinCode);
          
          if (!room) {
            ws.send(JSON.stringify({
              type: 'error',
              data: { message: 'Room not found' }
            }));
            return;
          }

          // Check if nickname exists
          if (room.students.find(s => s.nickname === nickname)) {
            ws.send(JSON.stringify({
              type: 'error',
              data: { message: 'Nickname already taken' }
            }));
            return;
          }

          const studentId = Date.now();
          room.students.push({
            id: studentId,
            nickname,
            isConnected: true
          });

          if (!connections.has(joinCode)) {
            connections.set(joinCode, []);
          }
          connections.get(joinCode).push(ws);
          
          ws.roomCode = joinCode;
          ws.studentId = studentId;

          ws.send(JSON.stringify({
            type: 'joined_room',
            data: {
              roomCode: joinCode,
              studentId,
              currentPhase: room.phase,
              problem: room.problem
            }
          }));

          // Update teacher
          broadcastToRoom(joinCode, {
            type: 'students_updated',
            data: { students: room.students }
          }, ws);
          break;

        case 'broadcast_problem':
          if (!ws.isTeacher) return;
          
          const roomForProblem = rooms.get(ws.roomCode);
          if (roomForProblem) {
            roomForProblem.problem = message.data.problem;
            roomForProblem.phase = 'invention';
            
            broadcastToRoom(ws.roomCode, {
              type: 'problem_broadcast',
              data: { problem: message.data.problem }
            }, ws);

            ws.send(JSON.stringify({
              type: 'problem_broadcast_success'
            }));
          }
          break;

        case 'submit_invention':
          const roomForInvention = rooms.get(ws.roomCode);
          if (roomForInvention && ws.studentId) {
            const invention = {
              id: Date.now(),
              studentId: ws.studentId,
              name: message.data.name,
              tagline: message.data.tagline,
              description: message.data.description
            };
            
            roomForInvention.inventions.push(invention);

            ws.send(JSON.stringify({
              type: 'invention_submitted',
              data: { invention }
            }));

            // Update teacher
            const inventionsWithStudents = roomForInvention.inventions.map(inv => {
              const student = roomForInvention.students.find(s => s.id === inv.studentId);
              return { ...inv, studentNickname: student?.nickname };
            });

            broadcastToRoom(ws.roomCode, {
              type: 'inventions_updated',
              data: {
                inventions: inventionsWithStudents,
                submissionCount: roomForInvention.inventions.length,
                totalStudents: roomForInvention.students.length
              }
            }, ws);
          }
          break;

        case 'start_voting':
          if (!ws.isTeacher) return;
          
          const roomForVoting = rooms.get(ws.roomCode);
          if (roomForVoting) {
            roomForVoting.phase = 'voting';
            
            const inventionsForVoting = roomForVoting.inventions.map(inv => {
              const student = roomForVoting.students.find(s => s.id === inv.studentId);
              return {
                id: inv.id,
                name: inv.name,
                tagline: inv.tagline,
                studentNickname: student?.nickname,
                studentId: inv.studentId
              };
            });

            broadcastToRoom(ws.roomCode, {
              type: 'voting_started',
              data: { inventions: inventionsForVoting }
            }, ws);

            ws.send(JSON.stringify({
              type: 'voting_started_success'
            }));
          }
          break;

        case 'submit_vote':
          const roomForVote = rooms.get(ws.roomCode);
          if (roomForVote && ws.studentId) {
            // Check if already voted
            if (roomForVote.votes.find(v => v.studentId === ws.studentId)) {
              ws.send(JSON.stringify({
                type: 'error',
                data: { message: 'You have already voted' }
              }));
              return;
            }

            // Check if voting for own invention
            const invention = roomForVote.inventions.find(i => i.id === message.data.inventionId);
            if (invention && invention.studentId === ws.studentId) {
              ws.send(JSON.stringify({
                type: 'error',
                data: { message: 'You cannot vote for your own invention' }
              }));
              return;
            }

            roomForVote.votes.push({
              studentId: ws.studentId,
              inventionId: message.data.inventionId
            });

            ws.send(JSON.stringify({
              type: 'vote_submitted',
              data: { inventionId: message.data.inventionId }
            }));

            // Update teacher
            broadcastToRoom(ws.roomCode, {
              type: 'votes_updated',
              data: {
                voteCount: roomForVote.votes.length,
                totalStudents: roomForVote.students.length
              }
            }, ws);
          }
          break;

        case 'show_results':
          if (!ws.isTeacher) return;
          
          const roomForResults = rooms.get(ws.roomCode);
          if (roomForResults) {
            roomForResults.phase = 'results';
            
            // Calculate results
            const results = roomForResults.inventions.map(inv => {
              const student = roomForResults.students.find(s => s.id === inv.studentId);
              const voteCount = roomForResults.votes.filter(v => v.inventionId === inv.id).length;
              return {
                ...inv,
                studentNickname: student?.nickname,
                voteCount
              };
            }).sort((a, b) => b.voteCount - a.voteCount);

            broadcastToRoom(ws.roomCode, {
              type: 'results_ready',
              data: { results }
            });
          }
          break;
      }
    } catch (error) {
      console.error('WebSocket error:', error);
    }
  });

  ws.on('close', () => {
    console.log('WebSocket disconnected');
    if (ws.roomCode && connections.has(ws.roomCode)) {
      const roomConnections = connections.get(ws.roomCode);
      const index = roomConnections.indexOf(ws);
      if (index > -1) {
        roomConnections.splice(index, 1);
      }
    }
  });
});

// Serve React app
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../dist/public/index.html'));
});

const PORT = process.env.PORT || 5000;
httpServer.listen(PORT, '0.0.0.0', () => {
  console.log(`Server running on port ${PORT}`);
});